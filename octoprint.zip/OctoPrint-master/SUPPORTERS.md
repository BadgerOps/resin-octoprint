# Supporters

Development of this version of OctoPrint wouldn't have been possible without
[financial support by the community](http://octoprint.org/support-octoprint/) -
thanks to everyone who contributed!

## Patreon Patrons

  * 3D Moniak
  * Aleph Objects, Inc.
  * Andrew Moorby
  * Arnljot Arntsen
  * Aurelio Bernal
  * Bart Zudell
  * Boris Hussein
  * Brad Jackson
  * Brad Mooneyham
  * Brent Fiegle
  * Brian E. Tyler
  * Charles Mitchell
  * Christopher Day
  * Christian Petropolis
  * COLLE+McVOY
  * CreativeTools
  * D Brian Kimmel
  * DeltaMaker 3D Printers
  * Doug Johnson
  * E3D BigBox
  * Erik de Bruijn
  * Ernesto Martinez
  * Exovite
  * Frank Sander
  * Gary Deen
  * Gary N McKinney
  * George Robles
  * Gregor Lütolf
  * J. Eckert
  * Jason Galarneau
  * Joe Korzeniewski
  * Josh Daniels
  * Joshua David Gregory
  * Kaile Riser
  * Kale Stedman
  * Kazuhiro Ogura
  * Korneel Bullens
  * Lamin Kivelä
  * M Khorakiwala
  * Makespace Madrid
  * Mark Lane
  * Mark Qvist
  * Mark Walker
  * Masayoshi Mitsui
  * Michael Aumock
  * Michael McDargh Sr
  * Miles Flavel
  * Nikolai Langer
  * Noe Ruiz
  * Patrick McGinnis
  * Peter Grace
  * Peter Schmehl
  * PRINT3Dforum.com
  * Robert Gusek
  * Roger Strolz
  * Roy Cortes
  * Samer Najia
  * SD3D
  * SeeMeCNC
  * Shane Ekerbicer
  * Simon Hallam
  * Stefan Krister
  * Steven Pearson
  * Sven Mueller
  * Terrance Shaw
  * Thomas Hatley
  * Trent Shumay

and 968 more wonderful people pledging on the [Patreon campaign](https://patreon.com/foosel)!
