.. _sec-modules-filemanager:

octoprint.filemanager
---------------------

.. automodule:: octoprint.filemanager
   :members:

.. _sec-modules-filemanager-analysis:

octoprint.filemanager.analysis
------------------------------

.. automodule:: octoprint.filemanager.analysis
   :members:

.. _sec-modules-filemanager-destinations:

octoprint.filemanager.destinations
----------------------------------

.. automodule:: octoprint.filemanager.destinations
   :members:

.. _sec-modules-filemanager-storage:

octoprint.filemanager.storage
-----------------------------

.. automodule:: octoprint.filemanager.storage
   :members: StorageInterface, LocalFileStorage

.. _sec-modules-filemanager-util:

octoprint.filemanager.util
--------------------------

.. automodule:: octoprint.filemanager.util
   :members: