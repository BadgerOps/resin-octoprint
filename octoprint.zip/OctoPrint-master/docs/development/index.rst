.. _sec-development:

###########
Development
###########

.. todo::

   This is where notes regarding developing OctoPrint will be placed, such as workflow for setting up the
   development environment, code guidelines etc.