.. _sec-plugins:

##################
Developing Plugins
##################

.. toctree::
   :maxdepth: 3

   gettingstarted.rst
   concepts.rst
   distributing.rst
   mixins.rst
   hooks.rst
   viewmodels.rst
