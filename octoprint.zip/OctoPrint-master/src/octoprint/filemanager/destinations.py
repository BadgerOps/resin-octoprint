# coding=utf-8
__license__ = 'GNU Affero General Public License http://www.gnu.org/licenses/agpl.html'

class FileDestinations(object):

	SDCARD = "sdcard"
	LOCAL = "local"
